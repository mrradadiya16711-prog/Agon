import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  Activity, TrendingUp, Eye, Bookmark, MousePointerClick, BrainCircuit,
  ArrowRight, Instagram, Facebook, Utensils, Sparkles, Heart, Share2,
} from "lucide-react";
import { DEMO_INSIGHTS, TOP_POSTS } from "../lib/dashboardData";

// --- live data simulation ---
type Series = { views: number[]; saves: number[]; clicks: number[] };

function nextValue(last: number, vol: number, bias = 0) {
  return Math.max(10, Math.round(last + (Math.random() - 0.5 + bias) * vol));
}

function buildPath(data: number[], w: number, h: number, pad = 8) {
  if (data.length < 2) return "";
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const step = (w - pad * 2) / (data.length - 1);
  return data
    .map((v, i) => {
      const x = pad + i * step;
      const y = h - pad - ((v - min) / range) * (h - pad * 2);
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
}

const METRICS = [
  { key: "views", label: "Views", icon: Eye, color: "var(--color-terracotta)" },
  { key: "saves", label: "Saves", icon: Bookmark, color: "var(--color-olive)" },
  { key: "clicks", label: "Clicks", icon: MousePointerClick, color: "var(--color-saffron)" },
] as const;

function useLiveSeries(seed: Series) {
  const [series, setSeries] = useState<Series>(seed);
  useEffect(() => {
    const id = setInterval(() => {
      setSeries((prev) => ({
        views: [...prev.views.slice(-19), nextValue(prev.views[prev.views.length - 1], 200, 0.1)],
        saves: [...prev.saves.slice(-19), nextValue(prev.saves[prev.saves.length - 1], 12, 0.08)],
        clicks: [...prev.clicks.slice(-19), nextValue(prev.clicks[prev.clicks.length - 1], 7, 0.08)],
      }));
    }, 2000);
    return () => clearInterval(id);
  }, []);
  return series;
}

// --- platform chart card ---
function PlatformChart({
  platform,
  series,
  color,
  icon: Icon,
  isLive,
}: {
  platform: string;
  series: Series;
  color: string;
  icon: any;
  isLive: boolean;
}) {
  const [active, setActive] = useState<(typeof METRICS)[number]["key"]>("views");
  const activeData = series[active];
  const activeMeta = METRICS.find((m) => m.key === active)!;
  const path = buildPath(activeData, 520, 200);
  const last = activeData[activeData.length - 1];
  const first = activeData[0];
  const delta = Math.round(((last - first) / first) * 100);

  return (
    <div className="rounded-2xl border border-cream-deep bg-cream p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-xl text-white" style={{ backgroundColor: color }}>
            <Icon className="h-5 w-5" />
          </span>
          <div>
            <div className="font-display text-base font-bold text-ink">{platform}</div>
            <div className="text-[11px] text-ink-soft">Last 24 hours</div>
          </div>
        </div>
        <div className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold ${isLive ? "bg-olive/10 text-olive-dark" : "bg-saffron/15 text-saffron"}`}>
          <span className={`h-1.5 w-1.5 rounded-full animate-softpulse ${isLive ? "bg-olive" : "bg-saffron"}`} />
          {isLive ? "Live" : "Demo"}
        </div>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {METRICS.map((m) => {
          const isActive = active === m.key;
          return (
            <button
              key={m.key}
              onClick={() => setActive(m.key)}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${isActive ? "bg-ink text-cream" : "bg-cream-deep/60 text-ink-soft hover:bg-cream-deep"}`}
            >
              <m.icon className="h-3.5 w-3.5" style={{ color: isActive ? m.color : undefined }} />
              {m.label}
            </button>
          );
        })}
      </div>

      <div className="mt-4">
        <svg viewBox="0 0 520 200" className="h-48 w-full" preserveAspectRatio="none">
          <defs>
            <linearGradient id={`fill-${platform}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={activeMeta.color} stopOpacity="0.25" />
              <stop offset="100%" stopColor={activeMeta.color} stopOpacity="0" />
            </linearGradient>
          </defs>
          {[0.25, 0.5, 0.75].map((p) => (
            <line key={p} x1="8" y1={200 * p} x2="512" y2={200 * p} stroke="var(--color-cream-deep)" strokeWidth="1" />
          ))}
          {path && (
            <>
              <path d={`${path} L512,192 L8,192 Z`} fill={`url(#fill-${platform})`} />
              <path d={path} fill="none" stroke={activeMeta.color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
              <circle
                cx={512}
                cy={192 - ((last - Math.min(...activeData)) / (Math.max(...activeData) - Math.min(...activeData) || 1)) * 176}
                r="4.5"
                fill={activeMeta.color}
                className="animate-softpulse"
              />
            </>
          )}
        </svg>
      </div>

      <div className="mt-3 flex items-center justify-between border-t border-cream-deep pt-3">
        <div>
          <span className="font-display text-xl font-extrabold text-ink">{last.toLocaleString()}</span>
          <span className="ml-2 text-xs font-medium uppercase tracking-wide text-ink-soft">{activeMeta.label}</span>
        </div>
        <div className={`inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-bold ${delta >= 0 ? "bg-olive/10 text-olive-dark" : "bg-terracotta/10 text-terracotta-dark"}`}>
          <TrendingUp className="h-3.5 w-3.5" />
          {delta >= 0 ? "+" : ""}{delta}%
        </div>
      </div>
    </div>
  );
}

// --- main dashboard ---
export default function Dashboard() {
  const igSeries = useLiveSeries({
    views: [420, 510, 480, 640, 590, 760, 720, 880, 820, 980, 940, 1120, 1080, 1240],
    saves: [12, 18, 15, 24, 21, 30, 27, 36, 33, 42, 39, 51, 48, 58],
    clicks: [4, 6, 5, 9, 7, 12, 10, 15, 13, 18, 16, 22, 20, 26],
  });
  const fbSeries = useLiveSeries({
    views: [280, 320, 300, 410, 380, 460, 440, 520, 490, 580, 560, 640, 610, 700],
    saves: [6, 9, 8, 13, 11, 16, 14, 20, 18, 24, 22, 28, 26, 32],
    clicks: [2, 3, 3, 5, 4, 7, 6, 9, 8, 11, 10, 13, 12, 15],
  });

  const [tick, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), 4000);
    return () => clearInterval(id);
  }, []);

  const totalViews = igSeries.views[igSeries.views.length - 1] + fbSeries.views[fbSeries.views.length - 1];
  const totalSaves = igSeries.saves[igSeries.saves.length - 1] + fbSeries.saves[fbSeries.saves.length - 1];
  const totalClicks = igSeries.clicks[igSeries.clicks.length - 1] + fbSeries.clicks[fbSeries.clicks.length - 1];

  const summaryCards = [
    { label: "Total views", value: totalViews.toLocaleString(), delta: "+18%", icon: Eye, color: "var(--color-terracotta)" },
    { label: "Total saves", value: totalSaves.toLocaleString(), delta: "+24%", icon: Bookmark, color: "var(--color-olive)" },
    { label: "Reservation clicks", value: totalClicks.toLocaleString(), delta: "+12%", icon: MousePointerClick, color: "var(--color-saffron)" },
    { label: "Engagement rate", value: "8.4%", delta: "+2.1%", icon: Heart, color: "#C13584" },
  ];

  return (
    <div className="min-h-screen bg-paper">
      {/* Top bar */}
      <header className="sticky top-0 z-40 border-b border-cream-deep bg-paper/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3.5 lg:px-8">
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-terracotta text-cream shadow-sm">
              <Utensils className="h-5 w-5" strokeWidth={2.4} />
            </span>
            <div>
              <div className="font-display text-lg font-extrabold leading-none tracking-tight text-ink">Mesa</div>
              <div className="text-[10px] text-ink-soft">Trattoria Sole</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden items-center gap-1.5 rounded-full bg-olive/10 px-3 py-1.5 text-xs font-semibold text-olive-dark sm:flex">
              <span className="h-1.5 w-1.5 rounded-full bg-olive animate-softpulse" />
              Autopilot on
            </div>
            <span className="grid h-9 w-9 place-items-center rounded-full bg-cream-deep text-xs font-bold text-ink-soft">TS</span>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-5 py-6 lg:px-8 lg:py-8">
        {/* Summary cards */}
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {summaryCards.map((c, i) => (
            <motion.div
              key={c.label}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              className="rounded-2xl border border-cream-deep bg-cream p-4"
            >
              <div className="flex items-center justify-between">
                <c.icon className="h-5 w-5" style={{ color: c.color }} />
                <span className="text-[11px] font-bold text-olive-dark">{c.delta}</span>
              </div>
              <div className="mt-2 font-display text-2xl font-extrabold text-ink">{c.value}</div>
              <div className="text-[11px] font-medium uppercase tracking-wide text-ink-soft">{c.label}</div>
            </motion.div>
          ))}
        </div>

        {/* Platform charts */}
        <div className="mt-5 grid gap-5 lg:grid-cols-2">
          <PlatformChart platform="Instagram" series={igSeries} color="#C13584" icon={Instagram} isLive={false} />
          <PlatformChart platform="Facebook" series={fbSeries} color="#1877F2" icon={Facebook} isLive={false} />
        </div>

        {/* AI #2 insights + top posts */}
        <div className="mt-5 grid gap-5 lg:grid-cols-5">
          {/* AI #2 panel */}
          <div className="rounded-2xl border border-cream-deep bg-ink p-5 text-cream lg:col-span-2">
            <div className="flex items-center gap-2.5">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-terracotta">
                <BrainCircuit className="h-5 w-5 text-cream" />
              </span>
              <div>
                <div className="font-display text-sm font-bold text-cream">AI #2 · Optimizer</div>
                <div className="text-[11px] text-cream/60">What it learned this week</div>
              </div>
            </div>

            <div className="mt-4 space-y-2.5">
              {DEMO_INSIGHTS.map((r, i) => (
                <div
                  key={r.metric}
                  className={`rounded-xl border border-cream/10 bg-cream/5 p-3 transition-all ${tick % 4 === i ? "ring-1 ring-saffron/50" : ""}`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold uppercase tracking-wide text-saffron">{r.metric}</span>
                    <ArrowRight className="h-3 w-3 text-cream/40" />
                  </div>
                  <div className="mt-1 text-xs font-medium text-cream/85">{r.insight}</div>
                  <div className="mt-1 text-[11px] text-cream/55">
                    → <span className="text-cream/80">{r.action}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 flex items-center gap-2 rounded-xl bg-olive-dark/50 px-3 py-2.5 text-[11px] text-cream/70">
              <Sparkles className="h-3.5 w-3.5 text-saffron" />
              AI #2 writes these rules back to AI #1 automatically
            </div>
          </div>

          {/* Top posts */}
          <div className="rounded-2xl border border-cream-deep bg-cream p-5 lg:col-span-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Activity className="h-4.5 w-4.5 text-terracotta" />
                <span className="font-display text-base font-bold text-ink">Top performing posts</span>
              </div>
              <span className="text-[11px] text-ink-soft">This week</span>
            </div>

            <div className="mt-4 space-y-3">
              {TOP_POSTS.map((post, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + i * 0.1 }}
                  className="flex gap-3 rounded-xl border border-cream-deep bg-paper p-3"
                >
                  <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-lg">
                    <img src={post.img} alt="" className="h-full w-full object-cover" />
                    <span className={`absolute bottom-1 left-1 grid h-5 w-5 place-items-center rounded-md text-white ${post.platform === "instagram" ? "bg-[#C13584]" : "bg-[#1877F2]"}`}>
                      {post.platform === "instagram" ? <Instagram className="h-3 w-3" /> : <Facebook className="h-3 w-3" />}
                    </span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="line-clamp-2 text-xs leading-snug text-ink">{post.caption}</p>
                    <div className="mt-1.5 flex items-center gap-3 text-[11px] font-medium text-ink-soft">
                      <span className="inline-flex items-center gap-1"><Eye className="h-3 w-3" /> {post.views}</span>
                      <span className="inline-flex items-center gap-1"><Bookmark className="h-3 w-3" /> {post.saves}</span>
                      <span className="inline-flex items-center gap-1"><MousePointerClick className="h-3 w-3" /> {post.clicks}</span>
                      <span className="inline-flex items-center gap-1"><Share2 className="h-3 w-3" /> {Math.round(post.saves * 0.4)}</span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* footer note */}
        <div className="mt-5 rounded-xl border border-saffron/30 bg-saffron/5 px-4 py-3 text-center text-xs text-ink-soft">
          <span className="font-bold text-saffron">Demo data shown.</span> Once your backend is connected, this pulls real views, saves &amp; clicks from Meta every minute.
        </div>
      </main>
    </div>
  );
}
