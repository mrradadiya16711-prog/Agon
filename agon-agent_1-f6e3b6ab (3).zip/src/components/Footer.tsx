import { Utensils } from "lucide-react";
import { NAV_LINKS } from "../lib/data";

export default function Footer() {
  return (
    <footer className="border-t border-cream-deep bg-cream/60">
      <div className="mx-auto max-w-7xl px-5 py-10 lg:px-8">
        <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
          <a href="#top" className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-terracotta text-cream"><Utensils className="h-5 w-5" /></span>
            <span className="font-display text-xl font-extrabold tracking-tight text-ink">Mesa</span>
          </a>
          <div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-sm text-ink-soft">
            {NAV_LINKS.map((l) => (
              <a key={l.href} href={l.href} className="transition-colors hover:text-terracotta">{l.label}</a>
            ))}
          </div>
        </div>
        <div className="mt-6 border-t border-cream-deep pt-5 text-center text-xs text-ink-soft">
          © {new Date().getFullYear()} Mesa — one system, one restaurant. Not affiliated with Meta or NVIDIA.
        </div>
      </div>
    </footer>
  );
}
