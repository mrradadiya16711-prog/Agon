import { motion } from "framer-motion";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import LiveMiniChart from "./LiveMiniChart";

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden bg-grain pt-28 pb-16 lg:pt-36 lg:pb-24">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -top-24 -left-24 h-96 w-96 rounded-full bg-terracotta-soft/30 blur-3xl" />
        <div className="absolute top-40 right-0 h-80 w-80 rounded-full bg-saffron/20 blur-3xl" />
        <div className="absolute bottom-0 left-1/3 h-72 w-72 rounded-full bg-olive-soft/20 blur-3xl" />
      </div>

      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-12">
          <div className="lg:col-span-6">
            <motion.h1
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55 }}
              className="font-display text-4xl font-extrabold leading-[1.05] tracking-tight text-ink sm:text-5xl lg:text-6xl"
            >
              Two AIs run your restaurant's social.
              <span className="relative text-terracotta">
                {" "}One posts. One improves it.
                <svg className="absolute -bottom-2 left-0 h-2.5 w-full text-saffron" viewBox="0 0 200 12" preserveAspectRatio="none" fill="none">
                  <path d="M2 9 C 60 2, 140 2, 198 9" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" />
                </svg>
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.1 }}
              className="mt-6 max-w-lg text-lg leading-relaxed text-ink-soft"
            >
              Sold to one restaurant. Yours alone.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.18 }}
              className="mt-7 flex flex-wrap items-center gap-3"
            >
              <a
                href="#connect"
                className="group inline-flex items-center gap-2 rounded-xl bg-terracotta px-5 py-3.5 text-sm font-semibold text-cream shadow-sm transition-all hover:bg-terracotta-dark hover:shadow-md"
              >
                Connect your keys
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </a>
              <a
                href="#analytics"
                className="inline-flex items-center gap-2 rounded-xl border border-cream-deep bg-cream/60 px-5 py-3.5 text-sm font-semibold text-ink transition-all hover:bg-cream-deep"
              >
                See live data
              </a>
            </motion.div>

            <motion.ul
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.28 }}
              className="mt-6 flex flex-wrap gap-x-6 gap-y-2 text-sm text-ink-soft"
            >
              {["Exclusive to you", "Self-improving", "No subscription"].map((t) => (
                <li key={t} className="inline-flex items-center gap-1.5">
                  <CheckCircle2 className="h-4 w-4 text-olive" />
                  {t}
                </li>
              ))}
            </motion.ul>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="lg:col-span-6"
          >
            <LiveMiniChart />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
