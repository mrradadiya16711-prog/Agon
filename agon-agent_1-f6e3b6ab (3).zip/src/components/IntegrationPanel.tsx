import { useState } from "react";
import { motion } from "framer-motion";
import { Check, Eye, EyeOff, Loader2, ShieldCheck, Database, Server } from "lucide-react";
import { CONNECT_CARDS, type ConnectCard } from "../lib/data";
import { saveKey, removeKey } from "../lib/api";

function ConnectField({
  card,
  index,
  onConnected,
  onRemoved,
}: {
  card: ConnectCard;
  index: number;
  onConnected: (id: string) => void;
  onRemoved: (id: string) => void;
}) {
  const [value, setValue] = useState("");
  const [show, setShow] = useState(false);
  const [status, setStatus] = useState<"idle" | "saving" | "saved">("idle");

  const handleSave = async () => {
    if (!value.trim()) return;
    setStatus("saving");
    try {
      await saveKey(card.id, card.name, value);
      setStatus("saved");
      onConnected(card.id);
    } catch (err) {
      console.error("Save failed:", err);
      setStatus("idle");
      alert("Failed to save. Is the backend running? Check VITE_BACKEND_URL.");
    }
  };

  const handleRemove = async () => {
    try {
      await removeKey(card.id);
    } catch {
      // ignore — remove from UI anyway
    }
    setStatus("idle");
    setValue("");
    onRemoved(card.id);
  };

  const masked =
    status === "saved" && value.length > 8
      ? value.slice(0, 6) + "••••••••••••" + value.slice(-4)
      : value;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.4, delay: index * 0.07 }}
      className="rounded-2xl border border-cream-deep bg-cream p-5"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-xl text-white shadow-sm" style={{ backgroundColor: card.accent }}>
            <card.icon className="h-5 w-5" />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display text-xs font-bold text-ink-soft">Step {index + 1}</span>
              <span className="font-display text-base font-bold text-ink">{card.name}</span>
            </div>
            <div className="text-[11px] text-ink-soft">{card.hint}</div>
          </div>
        </div>
        {status === "saved" && (
          <span className="inline-flex items-center gap-1 rounded-full bg-olive/15 px-2.5 py-1 text-[11px] font-bold text-olive-dark">
            <Check className="h-3 w-3" /> Connected
          </span>
        )}
      </div>

      <div className="mt-4 flex gap-2">
        <div className="relative flex-1">
          <input
            type={show || status === "saving" ? "text" : "password"}
            value={status === "saved" ? masked : value}
            onChange={(e) => setValue(e.target.value)}
            placeholder={card.placeholder}
            disabled={status === "saved" || status === "saving"}
            className="w-full rounded-xl border border-cream-deep bg-paper px-3.5 py-2.5 pr-10 text-sm text-ink placeholder:text-ink-soft/60 focus:border-terracotta focus:outline-none focus:ring-2 focus:ring-terracotta/20 disabled:opacity-70"
          />
          {value && status !== "saved" && (
            <button
              onClick={() => setShow((s) => !s)}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-ink-soft hover:text-ink"
              aria-label="toggle visibility"
            >
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          )}
        </div>
        {status === "saved" ? (
          <button
            onClick={handleRemove}
            className="shrink-0 rounded-xl border border-cream-deep px-4 py-2.5 text-sm font-semibold text-ink-soft transition-colors hover:bg-cream-deep"
          >
            Remove
          </button>
        ) : (
          <button
            onClick={handleSave}
            disabled={!value.trim() || status === "saving"}
            className="shrink-0 inline-flex items-center gap-1.5 rounded-xl bg-ink px-4 py-2.5 text-sm font-semibold text-cream transition-colors hover:bg-olive-dark disabled:opacity-40"
          >
            {status === "saving" ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
            {status === "saving" ? "Saving" : "Save"}
          </button>
        )}
      </div>
    </motion.div>
  );
}

export default function IntegrationPanel() {
  const [connected, setConnected] = useState<Set<string>>(new Set());
  const count = connected.size;
  const allConnected = count === CONNECT_CARDS.length;

  return (
    <section id="connect" className="border-y border-cream-deep bg-cream/40 py-16 lg:py-24">
      <div className="mx-auto max-w-3xl px-5 lg:px-8">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-terracotta">
            <span className="h-1.5 w-1.5 rounded-full bg-terracotta" />
            Connect
          </div>
          <h2 className="mt-3 font-display text-3xl font-extrabold tracking-tight text-ink sm:text-4xl">
            Paste your keys here. That's it.
          </h2>
          <p className="mt-3 text-base text-ink-soft">
            Three fields. Save each one. Your system is live.
          </p>

          {/* progress */}
          <div className="mx-auto mt-5 flex max-w-xs items-center gap-2">
            {CONNECT_CARDS.map((c) => (
              <div key={c.id} className="flex-1">
                <div className={`h-1.5 rounded-full transition-colors ${connected.has(c.id) ? "bg-olive" : "bg-cream-deep"}`} />
              </div>
            ))}
            <span className="ml-1 text-xs font-bold text-ink-soft">{count}/3</span>
          </div>
        </div>

        <div className="mt-10 space-y-4">
          {CONNECT_CARDS.map((c, i) => (
            <ConnectField
              key={c.id}
              card={c}
              index={i}
              onConnected={(id) => setConnected((prev) => new Set(prev).add(id))}
              onRemoved={(id) =>
                setConnected((prev) => {
                  const next = new Set(prev);
                  next.delete(id);
                  return next;
                })
              }
            />
          ))}
        </div>

        <div className="mt-6 flex items-center justify-center gap-2 rounded-xl border border-cream-deep bg-paper px-4 py-3 text-xs text-ink-soft">
          <ShieldCheck className="h-4 w-4 text-olive" />
          Keys are encrypted at rest, never displayed after saving, and removable anytime.
        </div>

        {/* what happens next — honest about backend */}
        <div className="mt-4 rounded-xl border border-cream-deep bg-paper p-4">
          <div className="font-display text-sm font-bold text-ink">What these keys do</div>
          <div className="mt-3 space-y-2.5 text-xs text-ink-soft">
            <div className="flex gap-2.5">
              <Server className="mt-0.5 h-4 w-4 shrink-0 text-terracotta" />
              <span><b className="text-ink">Instagram &amp; Facebook tokens</b> — your backend uses these to publish posts (AI #1) and pull real views/saves/clicks from Meta's Insights API (AI #2).</span>
            </div>
            <div className="flex gap-2.5">
              <Database className="mt-0.5 h-4 w-4 shrink-0 text-olive" />
              <span><b className="text-ink">NVIDIA API key</b> — powers both AI agents' generation. Your backend sends it to NVIDIA NIM, never the browser.</span>
            </div>
          </div>
        </div>

        <div className="mt-5 text-center">
          <button
            className={`inline-flex items-center gap-2 rounded-xl px-6 py-3.5 text-sm font-semibold text-cream shadow-sm transition-all ${
              allConnected
                ? "bg-terracotta hover:bg-terracotta-dark hover:shadow-md"
                : "bg-ink/30 cursor-not-allowed"
            }`}
            disabled={!allConnected}
          >
            {allConnected ? "Launch the system" : `Connect all 3 (${count}/3 done)`}
          </button>
        </div>
      </div>
    </section>
  );
}
