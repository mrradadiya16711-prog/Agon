import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Activity, TrendingUp, ArrowUpRight, BrainCircuit } from "lucide-react";

function useLiveSeries(seed: number[], maxLen = 32) {
  const [data, setData] = useState<number[]>(seed);
  useEffect(() => {
    const id = setInterval(() => {
      setData((prev) => {
        const last = prev[prev.length - 1] ?? 400;
        const next = Math.max(120, Math.round(last + (Math.random() - 0.45) * 180));
        return [...prev.slice(-(maxLen - 1)), next];
      });
    }, 1400);
    return () => clearInterval(id);
  }, [maxLen]);
  return data;
}

function sparkPath(data: number[], w: number, h: number, pad = 6) {
  if (data.length < 2) return "";
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const step = (w - pad * 2) / (data.length - 1);
  return data
    .map((v, i) => {
      const x = pad + i * step;
      const y = h - pad - ((v - min) / range) * (h - pad * 2);
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
}

export default function LiveMiniChart() {
  const views = useLiveSeries([320, 410, 380, 520, 480, 610, 590, 720, 680, 810, 760, 920]);
  const W = 360;
  const H = 180;
  const path = sparkPath(views, W, H);
  const last = views[views.length - 1] ?? 0;
  const prev = views[views.length - 2] ?? last;
  const delta = last - prev;
  const up = delta >= 0;

  return (
    <div className="relative">
      <div className="pointer-events-none absolute -inset-3 -z-10 rounded-[2rem] bg-gradient-to-br from-terracotta/15 via-saffron/10 to-olive/15 blur-2xl" />

      <div className="overflow-hidden rounded-[1.5rem] border border-cream-deep bg-cream shadow-[0_20px_60px_-25px_rgba(42,37,33,0.35)]">
        <div className="flex items-center justify-between border-b border-cream-deep bg-cream-deep/60 px-4 py-3">
          <div className="flex items-center gap-2">
            <Activity className="h-4 w-4 text-terracotta" />
            <span className="font-display text-sm font-bold text-ink">Live post views</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs font-medium text-olive-dark">
            <span className="h-2 w-2 rounded-full bg-olive animate-softpulse" />
            Real-time
          </div>
        </div>

        <div className="grid grid-cols-3 gap-px bg-cream-deep/60 text-center">
          {[
            { label: "Views", value: last.toLocaleString(), icon: Activity },
            { label: "Trend", value: `${up ? "+" : ""}${delta}`, icon: TrendingUp },
            { label: "Saves/hr", value: "47", icon: ArrowUpRight },
          ].map((s) => (
            <div key={s.label} className="bg-cream px-2 py-3">
              <s.icon className="mx-auto h-4 w-4 text-terracotta" />
              <div className="mt-1 font-display text-lg font-extrabold text-ink">{s.value}</div>
              <div className="text-[10px] font-medium uppercase tracking-wide text-ink-soft">{s.label}</div>
            </div>
          ))}
        </div>

        <div className="p-4">
          <svg viewBox={`0 0 ${W} ${H}`} className="h-44 w-full" preserveAspectRatio="none">
            <defs>
              <linearGradient id="heroFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--color-terracotta)" stopOpacity="0.28" />
                <stop offset="100%" stopColor="var(--color-terracotta)" stopOpacity="0" />
              </linearGradient>
            </defs>
            {path && (
              <>
                <path d={`${path} L${W - 6},${H - 6} L6,${H - 6} Z`} fill="url(#heroFill)" />
                <path d={path} fill="none" stroke="var(--color-terracotta)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
              </>
            )}
          </svg>
        </div>

        <div className="flex items-center justify-between border-t border-cream-deep bg-cream-deep/40 px-4 py-2.5 text-xs">
          <span className="font-medium text-ink-soft">AI #2 reading this now</span>
          <span className="inline-flex items-center gap-1.5 font-semibold text-olive-dark">
            <BrainCircuit className="h-3.5 w-3.5" /> Learning
          </span>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.9, duration: 0.4 }}
        className="absolute -bottom-5 -left-5 hidden rounded-xl border border-cream-deep bg-cream px-3.5 py-2.5 shadow-lg sm:block"
      >
        <div className="flex items-center gap-2">
          <BrainCircuit className="h-4 w-4 text-terracotta" />
          <div>
            <div className="font-display text-xs font-bold text-ink">Rule updated by AI #2</div>
            <div className="text-[10px] text-ink-soft">"Post dinner at 6:15 PM"</div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
