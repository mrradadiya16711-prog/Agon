import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  Activity, TrendingUp, Eye, Bookmark, MousePointerClick, BrainCircuit, ArrowRight,
} from "lucide-react";
import { getAnalytics, getRules } from "../lib/api";

const DEMO_RULES = [
  { metric: "Reels vs carousels", insight: "Reels drive 3.1× more saves", action: "Prioritize Reels for new dishes" },
  { metric: "Best post time", insight: "6:15 PM beats 5:00 PM by 42%", action: "Shift dinner posts to 6:15 PM" },
  { metric: "Hook style", insight: "Price-mention hooks double saves", action: "Lead with price on specials" },
  { metric: "Caption length", insight: "90–120 chars gets most shares", action: "Trim captions under 120 chars" },
];

type Series = { views: number[]; saves: number[]; clicks: number[] };

function nextValue(last: number, volatility: number, bias = 0) {
  return Math.max(20, Math.round(last + (Math.random() - 0.5 + bias) * volatility));
}

function buildPath(data: number[], w: number, h: number, pad = 8) {
  if (data.length < 2) return "";
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const step = (w - pad * 2) / (data.length - 1);
  return data
    .map((v, i) => {
      const x = pad + i * step;
      const y = h - pad - ((v - min) / range) * (h - pad * 2);
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
}

const METRICS = [
  { key: "views", label: "Views", icon: Eye, color: "var(--color-terracotta)" },
  { key: "saves", label: "Saves", icon: Bookmark, color: "var(--color-olive)" },
  { key: "clicks", label: "Reserv. clicks", icon: MousePointerClick, color: "var(--color-saffron)" },
] as const;

export default function RealtimeGraph() {
  const [series, setSeries] = useState<Series>({
    views: [420, 510, 480, 640, 590, 760, 720, 880, 820, 980, 940, 1120, 1080, 1240],
    saves: [12, 18, 15, 24, 21, 30, 27, 36, 33, 42, 39, 51, 48, 58],
    clicks: [4, 6, 5, 9, 7, 12, 10, 15, 13, 18, 16, 22, 20, 26],
  });
  const [active, setActive] = useState<(typeof METRICS)[number]["key"]>("views");
  const [tick, setTick] = useState(0);
  const [isLiveData, setIsLiveData] = useState(false);
  const [rules, setRules] = useState<any[]>(DEMO_RULES);

  // Try to fetch real data from backend on mount
  useEffect(() => {
    let mounted = true;
    const fetchReal = async () => {
      try {
        const data = await getAnalytics("views", 20);
        if (mounted && data.hasRealData && data.values.length > 1) {
          setSeries((prev) => ({ ...prev, views: data.values }));
          setIsLiveData(true);
        }
      } catch {
        // Backend not connected yet — keep demo data
      }
      try {
        const rulesData = await getRules();
        if (mounted && rulesData.rules?.length > 0) {
          setRules(rulesData.rules);
        }
      } catch {
        // keep demo rules
      }
    };
    fetchReal();
    const id = setInterval(fetchReal, 60000); // refresh every minute
    return () => { mounted = false; clearInterval(id); };
  }, []);

  useEffect(() => {
    const id = setInterval(() => {
      setSeries((prev) => {
        const v = prev.views[prev.views.length - 1];
        const s = prev.saves[prev.saves.length - 1];
        const c = prev.clicks[prev.clicks.length - 1];
        // gentle upward bias so it "improves" over time — the optimizer working
        return {
          views: [...prev.views.slice(-19), nextValue(v, 220, 0.12)],
          saves: [...prev.saves.slice(-19), nextValue(s, 14, 0.1)],
          clicks: [...prev.clicks.slice(-19), nextValue(c, 8, 0.1)],
        };
      });
      setTick((t) => t + 1);
    }, 1800);
    return () => clearInterval(id);
  }, []);

  const W = 760;
  const H = 280;
  const activeData = series[active];
  const activeMeta = METRICS.find((m) => m.key === active)!;
  const path = buildPath(activeData, W, H);
  const last = activeData[activeData.length - 1];
  const first = activeData[0];
  const totalDelta = Math.round(((last - first) / first) * 100);

  return (
    <section id="analytics" className="relative overflow-hidden border-y border-cream-deep bg-cream/40 py-16 lg:py-24">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute right-0 top-20 h-80 w-80 rounded-full bg-terracotta-soft/15 blur-3xl" />
      </div>
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-terracotta">
            <span className="h-1.5 w-1.5 rounded-full bg-terracotta animate-softpulse" />
            Live analytics
          </div>
          <h2 className="mt-3 font-display text-3xl font-extrabold tracking-tight text-ink sm:text-4xl">
            Your content, live. AI #2 learns from it.
          </h2>
          <p className="mt-3 text-base text-ink-soft">
            Views, saves, clicks — updating every minute. AI #2 reads it all and makes AI #1 smarter.
          </p>
        </div>

        <div className="mt-10 grid gap-5 lg:grid-cols-3">
          {/* main chart */}
          <div className="lg:col-span-2 rounded-2xl border border-cream-deep bg-cream p-5 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Activity className="h-4.5 w-4.5 text-terracotta" />
                <span className="font-display text-base font-bold text-ink">Performance · last 24h</span>
              </div>
              <div className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold ${isLiveData ? "bg-olive/10 text-olive-dark" : "bg-saffron/15 text-saffron"}`}>
                <span className={`h-1.5 w-1.5 rounded-full animate-softpulse ${isLiveData ? "bg-olive" : "bg-saffron"}`} />
                {isLiveData ? "Live data" : "Demo data"}
              </div>
            </div>

            {/* metric toggle */}
            <div className="mt-4 flex flex-wrap gap-2">
              {METRICS.map((m) => {
                const isActive = active === m.key;
                return (
                  <button
                    key={m.key}
                    onClick={() => setActive(m.key)}
                    className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
                      isActive ? "bg-ink text-cream" : "bg-cream-deep/60 text-ink-soft hover:bg-cream-deep"
                    }`}
                  >
                    <m.icon className="h-3.5 w-3.5" style={{ color: isActive ? m.color : undefined }} />
                    {m.label}
                  </button>
                );
              })}
            </div>

            {/* chart */}
            <div className="relative mt-4">
              <svg viewBox={`0 0 ${W} ${H}`} className="h-64 w-full" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="chartFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={activeMeta.color} stopOpacity="0.25" />
                    <stop offset="100%" stopColor={activeMeta.color} stopOpacity="0" />
                  </linearGradient>
                </defs>
                {/* grid lines */}
                {[0.25, 0.5, 0.75].map((p) => (
                  <line key={p} x1="8" y1={H * p} x2={W - 8} y2={H * p} stroke="var(--color-cream-deep)" strokeWidth="1" />
                ))}
                {path && (
                  <>
                    <path d={`${path} L${W - 8},${H - 8} L8,${H - 8} Z`} fill="url(#chartFill)" />
                    <path d={path} fill="none" stroke={activeMeta.color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                    {/* moving dot at the end */}
                    <circle
                      cx={W - 8}
                      cy={H - 8 - ((last - Math.min(...activeData)) / (Math.max(...activeData) - Math.min(...activeData) || 1)) * (H - 16)}
                      r="5"
                      fill={activeMeta.color}
                      className="animate-softpulse"
                    />
                  </>
                )}
              </svg>
            </div>

            <div className="mt-3 flex items-center justify-between border-t border-cream-deep pt-3 text-sm">
              <div>
                <span className="font-display text-2xl font-extrabold text-ink">{last.toLocaleString()}</span>
                <span className="ml-2 text-xs font-medium uppercase tracking-wide text-ink-soft">{activeMeta.label} now</span>
              </div>
              <div className={`inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-bold ${totalDelta >= 0 ? "bg-olive/10 text-olive-dark" : "bg-terracotta/10 text-terracotta-dark"}`}>
                <TrendingUp className="h-3.5 w-3.5" />
                {totalDelta >= 0 ? "+" : ""}{totalDelta}% since start
              </div>
            </div>
          </div>

          {/* AI #2 insight feed */}
          <div className="rounded-2xl border border-cream-deep bg-ink p-5 text-cream shadow-sm">
            <div className="flex items-center gap-2">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-terracotta"><BrainCircuit className="h-5 w-5 text-cream" /></span>
              <div>
                <div className="font-display text-sm font-bold text-cream">AI #2 · Optimizer</div>
                <div className="text-[11px] text-cream/60">Rules written back to AI #1</div>
              </div>
            </div>

            <div className="mt-4 space-y-2.5">
              {rules.map((r: any, i: number) => (
                <motion.div
                  key={r.metric}
                  initial={{ opacity: 0, x: 10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.08, duration: 0.35 }}
                  className={`rounded-xl border border-cream/10 bg-cream/5 p-3 ${tick % 4 === i ? "ring-1 ring-saffron/50" : ""}`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold uppercase tracking-wide text-saffron">{r.metric}</span>
                    <ArrowRight className="h-3 w-3 text-cream/40" />
                  </div>
                  <div className="mt-1 text-xs font-medium text-cream/85">{r.insight}</div>
                  <div className="mt-1.5 text-[11px] text-cream/55">
                    → <span className="text-cream/80">{r.action}</span>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="mt-4 flex items-center gap-2 rounded-xl bg-olive-dark/50 px-3 py-2.5 text-[11px] text-cream/70">
              <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-saffron animate-softpulse" />
              Loop closed {tick > 0 ? `${tick}×` : "live"} — AI #1 applies rules on next draft
            </div>
          </div>
        </div>

        <div className="mt-5 rounded-xl border border-saffron/30 bg-saffron/5 px-4 py-3 text-center text-xs text-ink-soft">
          {isLiveData ? (
            <><span className="font-bold text-olive-dark">Live data.</span> Streaming from Meta Insights API via your backend.</>
          ) : (
            <><span className="font-bold text-saffron">Demo data shown.</span> Once your backend is connected, this pulls real views, saves &amp; clicks from Meta every minute.</>
          )}
        </div>
      </div>
    </section>
  );
}
