import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { AGENTS } from "../lib/data";

export default function TwoAI() {
  return (
    <section id="overview" className="mx-auto max-w-7xl px-5 py-16 lg:px-8 lg:py-24">
      <div className="grid gap-5 md:grid-cols-2">
        {AGENTS.map((a, i) => (
          <motion.div
            key={a.name}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.4, delay: i * 0.1 }}
            className="rounded-2xl border border-cream-deep bg-cream p-8 text-center"
          >
            <span
              className="mx-auto grid h-14 w-14 place-items-center rounded-2xl text-cream shadow-sm"
              style={{ backgroundColor: a.accent }}
            >
              <a.icon className="h-7 w-7" />
            </span>
            <div className="mt-4 text-xs font-semibold uppercase tracking-[0.16em]" style={{ color: a.accent }}>
              {a.tag}
            </div>
            <h3 className="mt-1 font-display text-2xl font-extrabold text-ink">{a.name}</h3>
            <p className="mt-2 text-base text-ink-soft">{a.oneLiner}</p>
          </motion.div>
        ))}
      </div>

      {/* loop line */}
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="mt-5 flex items-center justify-center gap-3 rounded-2xl border border-cream-deep bg-paper py-4 text-sm font-semibold text-ink-soft"
      >
        <span className="text-terracotta">AI #1 posts</span>
        <ArrowRight className="h-4 w-4 text-saffron" />
        <span className="text-olive">AI #2 learns</span>
        <ArrowRight className="h-4 w-4 text-saffron" />
        <span className="text-terracotta">AI #1 posts better</span>
      </motion.div>
    </section>
  );
}
