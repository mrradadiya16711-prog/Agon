import type { ReactNode } from "react";
import { Check } from "lucide-react";

// --- Text input ---
export function TextField({
  label, value, onChange, placeholder, hint,
}: {
  label: string; value: string; onChange: (v: string) => void;
  placeholder?: string; hint?: string;
}) {
  return (
    <div>
      <label className="block font-display text-sm font-bold text-ink">{label}</label>
      {hint && <p className="mt-0.5 text-xs text-ink-soft">{hint}</p>}
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="mt-2 w-full rounded-xl border border-cream-deep bg-paper px-4 py-3 text-sm text-ink placeholder:text-ink-soft/50 focus:border-terracotta focus:outline-none focus:ring-2 focus:ring-terracotta/20"
      />
    </div>
  );
}

// --- Select (dropdown) ---
export function SelectField({
  label, value, onChange, options, hint,
}: {
  label: string; value: string; onChange: (v: string) => void;
  options: { value: string; label: string }[]; hint?: string;
}) {
  return (
    <div>
      <label className="block font-display text-sm font-bold text-ink">{label}</label>
      {hint && <p className="mt-0.5 text-xs text-ink-soft">{hint}</p>}
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-2 w-full rounded-xl border border-cream-deep bg-paper px-4 py-3 text-sm text-ink focus:border-terracotta focus:outline-none focus:ring-2 focus:ring-terracotta/20"
      >
        <option value="" disabled>Select one…</option>
        {options.map((o) => (
          <option key={o.value} value={o.value}>{o.label}</option>
        ))}
      </select>
    </div>
  );
}

// --- Radio cards (single select with descriptions) ---
export function RadioCards({
  value, onChange, options, columns = 1,
}: {
  value: string; onChange: (v: string) => void;
  options: { value: string; label: string; desc?: string }[];
  columns?: 1 | 2;
}) {
  return (
    <div className={`grid gap-3 ${columns === 2 ? "sm:grid-cols-2" : ""}`}>
      {options.map((o) => {
        const selected = value === o.value;
        return (
          <button
            key={o.value}
            type="button"
            onClick={() => onChange(o.value)}
            className={`flex items-start gap-3 rounded-xl border p-4 text-left transition-all ${
              selected
                ? "border-terracotta bg-terracotta/5 ring-2 ring-terracotta/20"
                : "border-cream-deep bg-paper hover:border-terracotta-soft/40"
            }`}
          >
            <span className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border-2 transition-colors ${
              selected ? "border-terracotta bg-terracotta" : "border-cream-deep"
            }`}>
              {selected && <Check className="h-3 w-3 text-cream" />}
            </span>
            <div>
              <div className="text-sm font-bold text-ink">{o.label}</div>
              {o.desc && <div className="mt-0.5 text-xs text-ink-soft">{o.desc}</div>}
            </div>
          </button>
        );
      })}
    </div>
  );
}

// --- Checkbox chips (multi-select) ---
export function ChipMultiSelect({
  values, onToggle, options, label,
}: {
  values: string[]; onToggle: (v: string) => void;
  options: { value: string; label: string }[]; label?: string;
}) {
  return (
    <div>
      {label && <div className="mb-3 font-display text-sm font-bold text-ink">{label}</div>}
      <div className="flex flex-wrap gap-2">
        {options.map((o) => {
          const selected = values.includes(o.value);
          return (
            <button
              key={o.value}
              type="button"
              onClick={() => onToggle(o.value)}
              className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-2 text-sm font-medium transition-all ${
                selected
                  ? "border-terracotta bg-terracotta text-cream"
                  : "border-cream-deep bg-paper text-ink-soft hover:border-terracotta-soft/50 hover:text-ink"
              }`}
            >
              {selected && <Check className="h-3.5 w-3.5" />}
              {o.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// --- Section wrapper ---
export function StepContent({
  title, subtitle, children,
}: {
  title: string; subtitle: string; children: ReactNode;
}) {
  return (
    <div>
      <h2 className="font-display text-2xl font-extrabold tracking-tight text-ink sm:text-3xl">{title}</h2>
      <p className="mt-2 text-sm text-ink-soft sm:text-base">{subtitle}</p>
      <div className="mt-6 space-y-5">{children}</div>
    </div>
  );
}
