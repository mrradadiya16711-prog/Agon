import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, ArrowRight, Check, Utensils, Sparkles } from "lucide-react";
import { STEPS, EMPTY_DATA, type OnboardingData } from "../../lib/onboardingData";
import {
  RESTAURANT_TYPES, LOCATION_COUNTS, BRAND_VOICES, TARGET_AUDIENCES,
  MENU_CATEGORIES, PROMOTION_GOALS, POSTING_FREQUENCIES, PLATFORMS,
  SEASONS, REVIEW_STYLES, APPROVAL_WORKFLOWS, getLabel,
} from "../../lib/onboardingData";
import {
  TextField, SelectField, RadioCards, ChipMultiSelect, StepContent,
} from "./FormFields";

export default function OnboardingWizard() {
  const [step, setStep] = useState(1);
  const [data, setData] = useState<OnboardingData>(EMPTY_DATA);
  const [done, setDone] = useState(false);

  const update = (key: keyof OnboardingData, value: any) =>
    setData((prev) => ({ ...prev, [key]: value }));

  const toggleArray = (key: keyof OnboardingData, value: string) =>
    setData((prev) => {
      const arr = prev[key] as string[];
      return {
        ...prev,
        [key]: arr.includes(value) ? arr.filter((v) => v !== value) : [...arr, value],
      };
    });

  const canProceed = (): boolean => {
    switch (step) {
      case 1: return !!(data.businessName && data.restaurantType && data.locationCount);
      case 2: return !!(data.brandVoice && data.targetAudiences.length > 0);
      case 3: return !!(data.menuCategories.length > 0 && data.promotionGoals.length > 0);
      case 4: return !!(data.postingFrequency && data.platforms.length > 0);
      case 5: return !!(data.reviewStyle && data.approvalWorkflow);
      default: return true;
    }
  };

  const next = () => {
    if (step < STEPS.length) setStep(step + 1);
    else setDone(true);
  };
  const back = () => step > 1 && setStep(step - 1);

  if (done) {
    return (
      <SuccessScreen
        data={data}
        onRestart={() => { setDone(false); setStep(1); setData(EMPTY_DATA); }}
      />
    );
  }

  return (
    <div className="mx-auto flex min-h-screen max-w-5xl flex-col lg:flex-row">
      {/* Sidebar — step progress */}
      <aside className="border-b border-cream-deep bg-cream/40 p-6 lg:w-72 lg:border-b-0 lg:border-r lg:p-8">
        <div className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-terracotta text-cream shadow-sm">
            <Utensils className="h-5 w-5" strokeWidth={2.4} />
          </span>
          <span className="font-display text-xl font-extrabold tracking-tight text-ink">Mesa</span>
        </div>

        <div className="mt-8 space-y-1">
          {STEPS.map((s) => {
            const isActive = s.id === step;
            const isComplete = s.id < step;
            return (
              <button
                key={s.id}
                onClick={() => s.id < step && setStep(s.id)}
                disabled={s.id > step}
                className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left transition-colors ${
                  isActive ? "bg-terracotta/10" : "hover:bg-cream-deep/40"
                } ${s.id > step ? "cursor-not-allowed opacity-40" : "cursor-pointer"}`}
              >
                <span className={`grid h-7 w-7 shrink-0 place-items-center rounded-lg text-xs font-bold transition-colors ${
                  isComplete ? "bg-olive text-cream" : isActive ? "bg-terracotta text-cream" : "bg-cream-deep text-ink-soft"
                }`}>
                  {isComplete ? <Check className="h-4 w-4" /> : s.id}
                </span>
                <span className={`text-sm font-semibold ${isActive ? "text-ink" : "text-ink-soft"}`}>
                  {s.short}
                </span>
              </button>
            );
          })}
        </div>

        <div className="mt-8 rounded-xl bg-olive/10 p-4">
          <Sparkles className="h-5 w-5 text-olive" />
          <p className="mt-2 text-xs leading-relaxed text-olive-dark">
            Mesa learns from your answers to write posts that sound like you. You can change any of this later.
          </p>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 p-6 lg:p-10">
        <div className="mx-auto max-w-2xl">
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.25 }}
            >
              {step === 1 && (
                <StepContent
                  title="Tell us about your restaurant"
                  subtitle="Let's start with the basics so Mesa knows who you are."
                >
                  <TextField
                    label="Business name"
                    value={data.businessName}
                    onChange={(v) => update("businessName", v)}
                    placeholder="e.g. Trattoria Sole"
                  />
                  <SelectField
                    label="Restaurant type"
                    value={data.restaurantType}
                    onChange={(v) => update("restaurantType", v)}
                    options={RESTAURANT_TYPES}
                    hint="Pick the one that fits best — you can add details later."
                  />
                  <SelectField
                    label="How many locations?"
                    value={data.locationCount}
                    onChange={(v) => update("locationCount", v)}
                    options={LOCATION_COUNTS}
                  />
                </StepContent>
              )}

              {step === 2 && (
                <StepContent
                  title="What's your brand voice?"
                  subtitle="This shapes how Mesa writes every caption. Pick the vibe that feels most like you."
                >
                  <div>
                    <div className="mb-3 font-display text-sm font-bold text-ink">Brand voice</div>
                    <RadioCards
                      value={data.brandVoice}
                      onChange={(v) => update("brandVoice", v)}
                      options={BRAND_VOICES}
                      columns={1}
                    />
                  </div>
                  <ChipMultiSelect
                    label="Who's your target audience? (Select all that apply)"
                    values={data.targetAudiences}
                    onToggle={(v) => toggleArray("targetAudiences", v)}
                    options={TARGET_AUDIENCES}
                  />
                </StepContent>
              )}

              {step === 3 && (
                <StepContent
                  title="What do you serve & promote?"
                  subtitle="Mesa uses this to know what content to create and when."
                >
                  <ChipMultiSelect
                    label="Menu categories (Select all that apply)"
                    values={data.menuCategories}
                    onToggle={(v) => toggleArray("menuCategories", v)}
                    options={MENU_CATEGORIES}
                  />
                  <ChipMultiSelect
                    label="What do you want to promote? (Select all that apply)"
                    values={data.promotionGoals}
                    onToggle={(v) => toggleArray("promotionGoals", v)}
                    options={PROMOTION_GOALS}
                  />
                </StepContent>
              )}

              {step === 4 && (
                <StepContent
                  title="When & where should Mesa post?"
                  subtitle="Set your posting rhythm and pick your platforms."
                >
                  <div>
                    <div className="mb-3 font-display text-sm font-bold text-ink">Posting frequency</div>
                    <RadioCards
                      value={data.postingFrequency}
                      onChange={(v) => update("postingFrequency", v)}
                      options={POSTING_FREQUENCIES}
                      columns={2}
                    />
                  </div>
                  <ChipMultiSelect
                    label="Which platforms? (Select all that apply)"
                    values={data.platforms}
                    onToggle={(v) => toggleArray("platforms", v)}
                    options={PLATFORMS}
                  />
                </StepContent>
              )}

              {step === 5 && (
                <StepContent
                  title="How hands-on do you want to be?"
                  subtitle="Set your automation preferences. You're always in control — change these anytime."
                >
                  <div>
                    <div className="mb-3 font-display text-sm font-bold text-ink">Seasonal campaigns</div>
                    <ChipMultiSelect
                      values={data.seasonalCampaigns}
                      onToggle={(v) => toggleArray("seasonalCampaigns", v)}
                      options={SEASONS}
                    />
                    <p className="mt-2 text-xs text-ink-soft">Mesa will plan ahead for the seasons you select. Skip if you don't want seasonal content.</p>
                  </div>
                  <div>
                    <div className="mb-3 font-display text-sm font-bold text-ink">Review response style</div>
                    <RadioCards
                      value={data.reviewStyle}
                      onChange={(v) => update("reviewStyle", v)}
                      options={REVIEW_STYLES}
                      columns={1}
                    />
                  </div>
                  <div>
                    <div className="mb-3 font-display text-sm font-bold text-ink">Approval workflow</div>
                    <RadioCards
                      value={data.approvalWorkflow}
                      onChange={(v) => update("approvalWorkflow", v)}
                      options={APPROVAL_WORKFLOWS}
                      columns={1}
                    />
                  </div>
                </StepContent>
              )}

              {step === 6 && (
                <StepContent
                  title="Review your setup"
                  subtitle="Make sure everything looks right. You can edit any section by clicking it."
                >
                  <ReviewSummary data={data} onEdit={(s) => setStep(s)} />
                </StepContent>
              )}
            </motion.div>
          </AnimatePresence>

          {/* Navigation */}
          <div className="mt-10 flex items-center justify-between border-t border-cream-deep pt-6">
            <button
              onClick={back}
              disabled={step === 1}
              className={`inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition-colors ${
                step === 1 ? "cursor-not-allowed text-ink-soft/40" : "text-ink-soft hover:bg-cream-deep"
              }`}
            >
              <ArrowLeft className="h-4 w-4" />
              Back
            </button>

            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-ink-soft">Step {step} of {STEPS.length}</span>
              <button
                onClick={next}
                disabled={!canProceed()}
                className={`inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold text-cream shadow-sm transition-all ${
                  canProceed()
                    ? "bg-terracotta hover:bg-terracotta-dark hover:shadow-md"
                    : "cursor-not-allowed bg-ink/20"
                }`}
              >
                {step === STEPS.length ? "Confirm & launch" : "Continue"}
                {step === STEPS.length ? <Check className="h-4 w-4" /> : <ArrowRight className="h-4 w-4" />}
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

// --- Review summary ---
function ReviewSummary({ data, onEdit }: { data: OnboardingData; onEdit: (step: number) => void }) {
  const sections = [
    {
      step: 1, title: "Business basics",
      items: [
        ["Business name", data.businessName],
        ["Restaurant type", getLabel(RESTAURANT_TYPES, data.restaurantType)],
        ["Locations", getLabel(LOCATION_COUNTS, data.locationCount)],
      ],
    },
    {
      step: 2, title: "Brand voice & audience",
      items: [
        ["Brand voice", getLabel(BRAND_VOICES, data.brandVoice)],
        ["Target audience", data.targetAudiences.map((v) => getLabel(TARGET_AUDIENCES, v)).join(", ")],
      ],
    },
    {
      step: 3, title: "Menu & content",
      items: [
        ["Menu categories", data.menuCategories.map((v) => getLabel(MENU_CATEGORIES, v)).join(", ")],
        ["Promotion goals", data.promotionGoals.map((v) => getLabel(PROMOTION_GOALS, v)).join(", ")],
      ],
    },
    {
      step: 4, title: "Posting & platforms",
      items: [
        ["Posting frequency", getLabel(POSTING_FREQUENCIES, data.postingFrequency)],
        ["Platforms", data.platforms.map((v) => getLabel(PLATFORMS, v)).join(", ")],
      ],
    },
    {
      step: 5, title: "Automation preferences",
      items: [
        ["Seasonal campaigns", data.seasonalCampaigns.length ? data.seasonalCampaigns.map((v) => getLabel(SEASONS, v)).join(", ") : "None selected"],
        ["Review response", getLabel(REVIEW_STYLES, data.reviewStyle)],
        ["Approval workflow", getLabel(APPROVAL_WORKFLOWS, data.approvalWorkflow)],
      ],
    },
  ];

  return (
    <div className="space-y-3">
      {sections.map((s) => (
        <div key={s.step} className="rounded-xl border border-cream-deep bg-paper p-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-sm font-bold text-ink">{s.title}</h3>
            <button
              onClick={() => onEdit(s.step)}
              className="text-xs font-semibold text-terracotta hover:underline"
            >
              Edit
            </button>
          </div>
          <dl className="mt-3 space-y-1.5">
            {s.items.map(([label, value]) => (
              <div key={label} className="flex gap-2 text-sm">
                <dt className="w-40 shrink-0 text-ink-soft">{label}</dt>
                <dd className="font-medium text-ink">{value || "—"}</dd>
              </div>
            ))}
          </dl>
        </div>
      ))}
    </div>
  );
}

// --- Success screen ---
function SuccessScreen({ data, onRestart }: { data: OnboardingData; onRestart: () => void }) {
  return (
    <div className="grid min-h-screen place-items-center p-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
        className="max-w-lg text-center"
      >
        <div className="mx-auto grid h-20 w-20 place-items-center rounded-3xl bg-olive text-cream shadow-lg">
          <Check className="h-10 w-10" strokeWidth={3} />
        </div>
        <h1 className="mt-6 font-display text-3xl font-extrabold tracking-tight text-ink">
          You're all set, {data.businessName || "chef"}!
        </h1>
        <p className="mt-3 text-base leading-relaxed text-ink-soft">
          Mesa now knows your restaurant, your voice, and your goals. Your first week of content is being drafted — you'll see it in your dashboard shortly.
        </p>
        <div className="mt-6 rounded-2xl border border-cream-deep bg-cream p-5 text-left">
          <div className="font-display text-sm font-bold text-ink">What happens next</div>
          <ul className="mt-3 space-y-2 text-sm text-ink-soft">
            <li className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-olive" /> Mesa drafts your first batch of posts in your brand voice</li>
            <li className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-olive" /> You review, tweak, or approve them</li>
            <li className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-olive" /> Posts publish on your chosen schedule to your platforms</li>
            <li className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-olive" /> AI #2 watches performance and makes future posts smarter</li>
          </ul>
        </div>
        <button
          onClick={onRestart}
          className="mt-6 inline-flex items-center gap-2 rounded-xl border border-cream-deep px-5 py-2.5 text-sm font-semibold text-ink-soft transition-colors hover:bg-cream-deep"
        >
          Start over
        </button>
      </motion.div>
    </div>
  );
}
